CREATE FUNCTION getDepartmentChildList(rootId VARCHAR(1000))
  RETURNS VARCHAR(1000)
  CHARSET utf8
  BEGIN
    DECLARE sTemp VARCHAR(1000);
    DECLARE sTempChd VARCHAR(1000);
  
    SET sTemp = '$';
    SET sTempChd =rootId;
  
    WHILE sTempChd is not null DO
     SET sTemp = concat(sTemp,',',sTempChd);
     SELECT group_concat(childrenid) INTO sTempChd FROM (SELECT '0' AS id,departmentid AS parentid,userid AS childrenid FROM sys_user_department UNION SELECT * FROM sys_department_department) as 

sys_department_department where FIND_IN_SET(parentid,sTempChd)>0;
 END WHILE;
    RETURN sTemp;
   END;
