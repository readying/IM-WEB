CREATE FUNCTION rc(departmentId VARCHAR(50))
  RETURNS VARCHAR(50)
  CHARSET utf8
  BEGIN
        DECLARE i varchar(50);
	set i = departmentId;
       
        WHILE (select count(*) from sys_department_department sdd where sdd.childrenId = i) <> 0 DO
         set i = (select sdd.parentId from sys_department_department sdd where sdd.childrenId = i);
     END WHILE;
    RETURN i;
   END;
