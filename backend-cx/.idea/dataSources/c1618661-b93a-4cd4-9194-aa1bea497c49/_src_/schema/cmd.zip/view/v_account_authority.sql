CREATE VIEW v_account_authority AS
  (SELECT
     `auth`.`ID`            AS `ID`,
     `auth`.`AUTHORITYNAME` AS `AUTHORITYNAME`,
     `auth`.`DESCRIPTION`   AS `DESCRIPTION`,
     `auth`.`CREATETIME`    AS `CREATETIME`,
     `auth`.`UPDATETIME`    AS `UPDATETIME`,
     `auth`.`IFUSE`         AS `IFUSE`,
     `auth`.`ORDERNUM`      AS `ORDERNUM`,
     `a`.`USERNAME`         AS `USERNAME`,
     `a`.`TOKEN`            AS `TOKEN`
   FROM `cmd`.`sys_account` `a`
     JOIN `cmd`.`sys_account_role` `ar`
     JOIN `cmd`.`sys_role` `r`
     JOIN `cmd`.`sys_role_authority` `ra`
     JOIN `cmd`.`sys_authority` `auth`
   WHERE ((`a`.`ID` = `ar`.`ACCOUNTID`) AND (`ar`.`ROLEID` = `ra`.`ROLEID`) AND (`auth`.`ID` = `ra`.`AUTHORITYID`)));
